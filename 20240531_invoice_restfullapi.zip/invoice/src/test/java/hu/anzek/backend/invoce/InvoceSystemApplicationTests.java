package hu.anzek.backend.invoce;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InvoceSystemApplicationTests {

//    @Test
//    void contextLoads() {
//    }

}
