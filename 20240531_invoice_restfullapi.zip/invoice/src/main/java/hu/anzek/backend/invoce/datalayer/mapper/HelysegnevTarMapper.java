package hu.anzek.backend.invoce.datalayer.mapper;
import hu.anzek.backend.invoce.datalayer.dto.HelysegnevTarDto;
import java.util.List;
import hu.anzek.backend.invoce.datalayer.model.HelysegnevTar;

@Mapper(componentModel = "spring")
public interface HelysegnevTarMapper {
	HelysegnevTarDto helysegnevTarToDto(HelysegnevTar helysegnevTar);
	HelysegnevTar dtoToHelysegnevTar(HelysegnevTarDto helysegnevTarDto);
	List<HelysegnevTarDto> helysegnevTarToDtos(List<HelysegnevTar> helysegnevTars);
	List<HelysegnevTar> dtosToHelysegnevTar(List<HelysegnevTarDto> helysegnevTarDtoList);
}
 